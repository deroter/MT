<?php
# Movable Type (r) (C) 2001-2010 Six Apart, Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id$

function smarty_block_mtincludeblock($args, $content, &$ctx, &$repeat) {
    if (!isset($content)) {
    } else {
        require_once("function.mtinclude.php");
        $vars =& $ctx->__stash['vars'];
        if (!$vars) {
            $vars = array();
            $ctx->__stash['vars'] =& $vars;
        }
        $name = $args['var'];
        $name or $name = 'contents';
        $oldval = $vars[$name];

        $vars[$name] = $args['token_fn'];
        $content = smarty_function_mtinclude($args, $ctx);
        $vars[$name] = $oldval;
    }
    return $content;
}
