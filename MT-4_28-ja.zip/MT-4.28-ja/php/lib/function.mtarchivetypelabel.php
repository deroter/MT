<?php
# Movable Type (r) (C) 2001-2010 Six Apart, Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id$

require_once("function.mtarchivelabel.php");
function smarty_function_mtarchivetypelabel($args, &$ctx) {
    return smarty_function_mtarchivelabel($args, $ctx);
}
?>
