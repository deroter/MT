# Copyright 2002-2006 Appnel Internet Solutions, LLC
# This code is distributed with permission by Six Apart

package FeedsLite::L10N::en_us;

use strict;

use base 'FeedsLite::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
