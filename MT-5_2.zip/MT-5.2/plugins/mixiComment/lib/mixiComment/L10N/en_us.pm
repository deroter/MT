package mixiComment::L10N::en_us;

use strict;

use base 'mixiComment::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
