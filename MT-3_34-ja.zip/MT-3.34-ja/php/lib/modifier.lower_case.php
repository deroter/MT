<?php
function smarty_modifier_lower_case($text) {
    return strtolower($text);
}
?>
