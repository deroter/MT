<?php
function smarty_modifier_sprintf($text, $format) {
    return sprintf($format, $text);
}
?>
