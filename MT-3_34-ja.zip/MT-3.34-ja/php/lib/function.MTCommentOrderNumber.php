<?php
function smarty_function_MTCommentOrderNumber($args, &$ctx) {
    return $ctx->stash('comment_order_num');
}
?>
