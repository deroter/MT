<?php
function smarty_function_MTSearchScript($args, &$ctx) {
    // status: complete
    // parameters: none
    return $ctx->mt->config['SearchScript'];
}
?>
