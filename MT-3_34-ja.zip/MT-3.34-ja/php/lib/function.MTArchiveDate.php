<?php
function smarty_function_MTArchiveDate($args, &$ctx) {
    return $ctx->_hdlr_date($args, $ctx);
}
?>
