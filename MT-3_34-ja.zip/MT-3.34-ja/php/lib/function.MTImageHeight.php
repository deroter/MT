<?php
function smarty_function_MTImageHeight($args, &$ctx) {
    // todo: needs work
    return $ctx->stash('ImageHeight');
}
?>
