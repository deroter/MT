<?php
function smarty_modifier_rtrim($text) {
    return rtrim($text);
}
?>
