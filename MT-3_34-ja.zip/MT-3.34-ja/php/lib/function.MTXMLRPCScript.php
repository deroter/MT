<?php
function smarty_function_MTXMLRPCScript($args, &$ctx) {
    // status: complete
    // parameters: none
    return $ctx->mt->config['XMLRPCScript'];
}
?>
