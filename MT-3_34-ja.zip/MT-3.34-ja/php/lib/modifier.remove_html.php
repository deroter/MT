<?php
function smarty_modifier_remove_html($text) {
    return strip_tags($text);
}
?>
