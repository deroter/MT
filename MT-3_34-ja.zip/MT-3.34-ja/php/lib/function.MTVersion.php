<?php
function smarty_function_MTVersion($args, &$ctx) {
    // status: complete
    // parameters: none
    return VERSION_ID;
}
?>
