<?php
function smarty_modifier_encode_php($text) {
    // TODO: needs work
    return addslashes($text);
}
?>
