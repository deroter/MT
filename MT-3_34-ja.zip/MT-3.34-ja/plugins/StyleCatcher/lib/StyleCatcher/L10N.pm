# Copyright 2001-2007 Six Apart. This code cannot be redistributed without
# permission from www.sixapart.com.  For more information, consult your
# Movable Type license.
#
# $Id: L10N.pm 1003 2007-01-05 23:46:47Z gboggs $

package StyleCatcher::L10N;
use strict;
use base 'MT::Plugin::L10N';

1;
