# SpamLookup plugin for Movable Type
# Author: Brad Choate, Six Apart (http://www.sixapart.com)
# Released under the Artistic License
#
# $Id: L10N.pm 48 2006-06-13 19:55:17Z jallen $

package spamlookup::L10N;
use strict;

use MT::Plugin::L10N;
@spamlookup::L10N::ISA = qw(MT::Plugin::L10N);

1;
