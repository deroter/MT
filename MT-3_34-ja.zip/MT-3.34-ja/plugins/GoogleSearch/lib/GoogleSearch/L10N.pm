# GoogleSearch plugin for Movable Type
# Author: Six Apart (http://www.sixapart.com)
# Released under the Artistic License
#
# $Id: L10N.pm 36 2006-06-13 16:17:15Z jallen $

package GoogleSearch::L10N;
use strict;
use base 'MT::Plugin::L10N';

1;
