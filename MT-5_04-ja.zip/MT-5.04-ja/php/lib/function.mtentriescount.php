<?php
# Movable Type (r) (C) 2001-2010 Six Apart, Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id: function.mtentriescount.php 5225 2010-01-27 07:14:14Z takayama $

function smarty_function_mtentriescount($args, &$ctx) {
    if ($ctx->stash('inside_with_subcategories')) {
        $entries = $ctx->stash('entries');
        if (empty($entries)) {
            return $ctx->tag('MTCategoryCount', $args);
        }
        $count = count($entries);
    } elseif ($ctx->stash('inside_mt_categories')) {
        return $ctx->tag('MTCategoryCount', $args);
    } elseif ($count = $ctx->stash('archive_count')) {
        # $count is set
    } else {
        $entries = $ctx->stash('entries');
        if (empty($entries) || !is_array($entries)){
            $blog = $ctx->stash('blog');
            $args['blog_id'] = $blog->blog_id;
            $entries =& $ctx->mt->db()->fetch_entries($args);
        }
    
        $lastn = $ctx->stash('_entries_lastn');
        if ($lastn && $lastn <= count($entries))
            $count = $lastn;
        else
            $count = count($entries);
    }
    return $ctx->count_format($count, $args);
}
?>
