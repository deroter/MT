// UK lang variables

tinyMCE.addToLang('youtube',{
title : 'YouTube ムービー挿入／編集',
desc : 'YouTube ムービー挿入／編集',
file : 'ムービー ID',
size : 'サイズ',
list : 'YouTube ムービー',
props : 'YouTube プロパティ',
general : '全般'
});
