// UK lang variables

tinyMCE.addToLang('template',{
title : 'テンプレート',
label : 'テンプレート',
desc_label : '概要',
desc : '定義済みテンプレート挿入',
select : 'テンプレート挿入',
preview : 'プレビュー',
warning : '警告: 他でテンプレートを編集した場合、編集結果が失われる場合があります',
def_date_format : '%Y-%m-%d %H:%M:%S',
months_long : new Array("１月", "２月", "３月", "４月", "５月", "６月", "７月", "８月", "９月", "10月", "11月", "12月"),
months_short : new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"),
day_long : new Array("日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日", "日曜日"),
day_short : new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
});
