// JA lang variables

tinyMCE.addToLang('',{
preview_desc : 'プレビュー'
});
