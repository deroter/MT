// JA lang variables

tinyMCE.addToLang('',{
print_desc : '���'
});
