// JA lang variables

tinyMCE.addToLang('',{
save_desc : '保存（フォームの送信）'
});
