// JA lang variables

tinyMCE.addToLang('',{
print_desc : '印刷'
});
