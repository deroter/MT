// JA lang variables

tinyMCE.addToLang('nonbreaking',{
desc : '空白(&amp;nbsp;)の挿入'
});
