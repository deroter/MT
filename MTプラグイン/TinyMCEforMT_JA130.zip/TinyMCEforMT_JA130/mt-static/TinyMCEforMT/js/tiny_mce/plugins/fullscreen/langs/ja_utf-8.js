// JA lang variables

tinyMCE.addToLang('',{
fullscreen_desc : 'フルスクリーンモードを切り替える'
});
