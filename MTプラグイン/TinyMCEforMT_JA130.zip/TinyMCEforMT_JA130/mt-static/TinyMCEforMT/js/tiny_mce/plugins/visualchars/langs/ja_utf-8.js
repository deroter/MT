// JA lang variables

tinyMCE.addToLang('visualchars',{
desc : '制御文字の表示／非表示を切り替える.'
});
