﻿// Japanese utf-8 variables

tinyMCELang['lang_zoom_prefix'] = '拡大する';