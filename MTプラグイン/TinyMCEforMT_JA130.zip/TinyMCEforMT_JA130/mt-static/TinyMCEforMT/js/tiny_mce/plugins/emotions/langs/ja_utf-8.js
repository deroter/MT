// JA lang variables

tinyMCE.addToLang('emotions',{
title : '絵文字の挿入',
desc : '絵文字',
cool : 'クール',
cry : '悲しい',
embarassed : '照れる',
foot_in_mouth : '失言',
frown : '眉をひそめる',
innocent : '無邪気',
kiss : 'キス',
laughing : '笑う',
money_mouth : 'お金！',
sealed : '内緒',
smile : '笑顔',
surprised : '驚く',
tongue_out : 'あっかんべー',
undecided : '悩む',
wink : 'ウィンク',
yell : '叫ぶ'
});
