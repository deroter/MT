// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : '全般',
tab_appearance : '表示',
tab_advanced : '詳細',
general : '全般',
title : 'タイトル',
preview : 'プレビュー',
constrain_proportions : '大きさを指定する',
langdir : '表示方向',
langcode : '言語',
long_desc : '詳細な説明',
style : 'スタイル',
classes : 'クラス',
ltr : '左から右へ',
rtl : '右から左へ',
id : 'ＩＤ',
image_map : 'イメージマップ',
swap_image : '画像の交換',
alt_image : '画像の交換を有効にする',
mouseover : 'マウスが重なった時',
mouseout : 'マウスが移動した時',
misc : 'その他の設定',
example_img : 'Appearance&nbsp;preview&nbsp;image',
missing_alt : '画像の説明が記入されていませんがよろしいですか？'
});
