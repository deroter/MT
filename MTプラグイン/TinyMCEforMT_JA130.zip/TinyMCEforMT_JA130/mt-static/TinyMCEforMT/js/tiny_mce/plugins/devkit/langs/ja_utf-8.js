// JA lang variables

tinyMCE.addToLang('devkit',{
title : 'TinyMCE開発キット',
info_tab : '情報',
settings_tab : '設定',
log_tab : 'ログ',
content_tab : '内容',
command_states_tab : 'コマンド',
undo_redo_tab : 'アンドゥ／再実行',
misc_tab : 'その他',
filter : 'フィルタ:',
clear_log : 'ログの消去',
refresh : '最新状態へ更新',
info_help : '最新状態へ更新を押下すると、表示中の情報を更新します。',
settings_help : '最新状態へ更新を押下すると、TinyMCE_Controlインスタンスへの設定値を表示します。',
content_help : '最新状態へ更新を押下すると、TinyMCE_ControlインスタンスのHTML文書を表示します。',
command_states_help : '最新状態へ更新を押下すると、現在のコマンドの実行結果を表示します。また、以下のリストはサポートされていないコマンドの一覧です。',
undo_redo_help : '最新状態へ更新を押下すると、アンドゥ／再実行のスタック内容を表示します。',
misc_help : 'その他のデバッグおよび開発ツール',
debug_events : 'イベントのデバッグ',
undo_diff : 'アンドゥレベルの比較'
});
