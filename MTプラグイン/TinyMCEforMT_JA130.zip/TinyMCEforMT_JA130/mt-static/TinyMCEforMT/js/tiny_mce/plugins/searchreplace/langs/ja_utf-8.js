// JA lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : '検索',
searchreplace_searchnext_desc : '再建策',
searchreplace_replace_desc : '検索／置換',
searchreplace_notfound : '検索が終了しました。検索文字列は見つかりませんでした。',
searchreplace_search_title : '検索',
searchreplace_replace_title : '検索／置換',
searchreplace_allreplaced : 'すべての検索文字列を置換しました。',
searchreplace_findwhat : '検索文字列',
searchreplace_replacewith : '置換文字列',
searchreplace_direction : '検索の方向',
searchreplace_up : '上へ',
searchreplace_down : '下へ',
searchreplace_case : '大文字／小文字を区別する',
searchreplace_findnext : '次を検索',
searchreplace_replace : '置換',
searchreplace_replaceall : '全て置換',
searchreplace_cancel : 'キャンセル'
});
