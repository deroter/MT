<?php
$strings["curr_dir"] 		= "現在のディレクトリ";
$strings["back"] 		= "一つ上へ戻る";
$strings["close"] 		= "閉じる";
$strings["create_dir"] 		= "作成するディレクトリ:";
$strings["create_dir_submit"] 	= "作成";
$strings["upload_file"] 	= "アップロードするファイル:";
$strings["upload_file_submit"] 	= "アップロード";
$strings["sending"] 		= "アップロード中 ...";
$strings["title"] 		= "画像及びファイルのアップロード＆管理";
?>