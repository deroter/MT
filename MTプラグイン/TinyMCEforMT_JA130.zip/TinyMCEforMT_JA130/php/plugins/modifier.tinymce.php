<?php
function smarty_modifier_tinymce($text) {
    return $text;
}
?>
