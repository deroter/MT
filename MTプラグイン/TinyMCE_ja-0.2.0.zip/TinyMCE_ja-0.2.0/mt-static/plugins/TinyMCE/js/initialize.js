/*
 *   initialize.js
 *
 *   Copyright (c) 2008 ToI-Planning <office@toi-planning.net>
 * 
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 * 
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 *   3. Neither the name of the authors nor the names of its contributors
 *      may be used to endorse or promote products derived from this
 *      software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  $Id$
 */
(function() {
	var original = tinyMCE.init;
	var parameters = {
		mode : "exact",
		elements : '',

		theme : "advanced",
		skin : 'mt',

		width : null,

		plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,movabletype",

		// Theme options
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,

		theme_advanced_statusbar_location : "bottom",
		theme_advanced_path : false,

		//theme_advanced_fonts : "Andale Mono=andale mono,times;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats",

		theme_advanced_resizing_min_height : 100,

		convert_urls : false,
		extended_valid_elements : "form[action|accept|accept-charset|enctype|method|class|style|mt::asset-id],iframe[src|width|height|name|align|frameborder|scrolling|marginheight|marginwidth]",
		cleanup : true,
		dialog_type : 'modal',

		init_instance_callback : function(ed) {
			var iframe = document.getElementById(ed.id + '_ifr');
			iframe.style.position = 'static';

			var container =
				ed.getContentAreaContainer().
				parentNode.parentNode.parentNode. parentNode.parentNode;
            var container2 = container.parentNode;

			if (container.className.match(/textarea-wrapper/i)) {
				container.style.padding = '0px';
				container.style.border = '0px';
			}
			if (container2.className.match(/textarea-wrapper/i)) {
				container2.style.padding = '0px';
				container2.style.border = '0px';
			}
		},

		setup : function(ed) {
			tinyMCE.addI18n({
				'ja': {
					'common': {
						'serif': '\u660e\u671d\u4f53',
						'sans-serif': '\u30b4\u30b7\u30c3\u30af\u4f53',
						'monospace': '\u7b49\u5e45\u30d5\u30a9\u30f3\u30c8'
					}
				}
			});
		},

		placement : null
	};

	tinyMCE.init = function() {
		if (! parameters['width']) {
			if (
				(typeof(jQuery) == 'undefined')
				|| (typeof(jQuery.mtAddEdgeClass) == 'undefined')
			) {
				parameters['width'] = '580';
			}
			else {
				parameters['width'] = jQuery('#main-content-inner').width();
			}
		}

		var param = {};
		for (k in parameters) {
			param[k] = parameters[k];
		}
		if (typeof(arguments[0]) == 'object') {
			var override = arguments[0];
			for (k in override) {
				if (
					(typeof(param[k]) == 'function')
					&& (typeof(override[k]) == 'function')
				) {
					(function(func, over) {
						param[k] = function() {
							var args = [ func ];
							for (var i = 0; i < arguments.length; i++) {
								args.push(arguments[i]);
							}
							over.apply(null, args);
						}
					})(param[k], override[k]);
				}
				else {
					param[k] = override[k];
				}
			}
		}
		original.apply(tinyMCE, [param]);
	};
})();
