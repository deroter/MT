package TinyMCE::L10N::en_us;

use strict;

use base 'TinyMCE::L10N';
use vars qw( %Lexicon );
%Lexicon = (
	'FontSettingDefault' => 'Default',
	'ContentCSSDefault' => 'Default',
	'ContentCSSURL' => 'URL',
	'ContentCSSContent' => 'CSS',
	'OtherSettingDefault' => 'Default',

    'ThemeAdvancedFontSizesExample' => 'eg. Big text=30px,Small text=small,My Text Size=.mytextsize',
    'ThemeAdvancedFontsNote' => '',
);

1;
