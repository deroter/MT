#   Copyright (c) 2008 ToI-Planning <office@toi-planning.net>
# 
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions
#   are met:
# 
#   1. Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#   3. Neither the name of the authors nor the names of its contributors
#      may be used to endorse or promote products derived from this
#      software without specific prior written permission.
#
#   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
#   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
#   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
#   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
#   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#  $Id$

package TinyMCE::Template::ContextHandlers;

use strict;

sub _hdlr_include_customized_fields {
    my($ctx, $args) = @_;

	require MT;
	my $app = MT->instance;
	my $blog = $app->blog;
	my $blog_id = $blog ? $blog->id : 0;

	my $plugin = $app->component('TinyMCE');

	my @tiny_mce_fields = @{
		$plugin->get_config_value('tiny_mce_fields') || []
	};
	if ($blog_id) {
		push(@tiny_mce_fields, @{ $plugin->get_config_value(
			'tiny_mce_fields', 'blog:' . $blog_id
		) || [] });
	}

    eval { require CustomFields::Field; };
    if ($@) {
        $ctx->var('tiny_mce_customized_fields', undef);
		return;
    }

	my @ids = (0);
	if ($blog_id) {
		push(@ids, $blog_id);
	}
	my (%customized_fields, %customized_fields_page);
	my @fields = CustomFields::Field->load({
		'blog_id' => \@ids,
		'type' => 'textarea',
	});
	foreach my $f (@fields) {
		my $hash = {};
        my $id = $f->id;
		$hash->{'key'} = $id;
		$hash->{'checked'} = grep( { $_ == $id } @tiny_mce_fields);
		$hash->{'name'} = $f->name;
		$hash->{'blog_id'} = $f->blog_id;

		if ($f->obj_type eq 'entry') {
			$customized_fields{$id} = $hash;
		}
		elsif ($f->obj_type eq 'page') {
			$customized_fields_page{$id} = $hash;
		}
	}

    $ctx->var(
		'tiny_mce_customized_fields',
		keys(%customized_fields) ? \%customized_fields : undef
	);
    $ctx->var(
		'tiny_mce_customized_fields_page',
		keys(%customized_fields_page) ? \%customized_fields_page : undef
	);

    $ctx->var(
		'tiny_mce_has_customized_fields',
		scalar(keys(%customized_fields))+scalar(keys(%customized_fields_page))
	);
}

sub _hdlr_javascript {
    my($ctx, $args) = @_;

	require TinyMCE::App;
	&TinyMCE::App::js_include({
		'wrapper' => defined($args->{'wrapper'}) ? $args->{'wrapper'} : undef,
	});
}

1;
