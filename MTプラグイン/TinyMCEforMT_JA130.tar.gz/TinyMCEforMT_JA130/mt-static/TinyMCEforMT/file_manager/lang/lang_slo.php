<?php
$strings["curr_dir"] 		= "Trenutni direktorij";
$strings["back"] 		= "nazaj";
$strings["close"] 		= "zapri";
$strings["create_dir"] 		= "Ustvari direktorij:";
$strings["create_dir_submit"] 	= "Ustvari";
$strings["upload_file"] 	= "Pošlji datoteko:";
$strings["upload_file_submit"] 	= "Pošlji";
$strings["sending"] 		= "Pošiljam ...";
$strings["title"] 		= "Raziskovalec datotek";
?>