<?php
$strings["curr_dir"] 		= "Current directory";
$strings["back"] 		= "back";
$strings["close"] 		= "close";
$strings["create_dir"] 		= "Create directory:";
$strings["create_dir_submit"] 	= "Create";
$strings["upload_file"] 	= "Upload file:";
$strings["upload_file_submit"] 	= "Upload";
$strings["sending"] 		= "Uploading ...";
$strings["title"] 		= "File Manager";
?>