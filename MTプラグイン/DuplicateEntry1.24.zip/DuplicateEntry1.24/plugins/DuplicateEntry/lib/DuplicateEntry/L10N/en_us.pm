package DuplicateEntry::L10N::en_us;

use strict;
use base 'DuplicateEntry::L10N';
use vars qw( %Lexicon );

our %Lexicon = (
);

1;