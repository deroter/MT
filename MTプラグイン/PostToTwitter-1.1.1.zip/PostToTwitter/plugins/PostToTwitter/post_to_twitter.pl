package MT::Plugin::PostToTwitter;

use strict;
use MT::Plugin;
@MT::Plugin::PostToTwitter::ISA = qw(MT::Plugin);

use vars qw($PLUGIN_NAME $VERSION $DEBUG);
$PLUGIN_NAME = 'PostToTwitter';
$VERSION = '1.1.1';
$DEBUG = 0;

use MT;
my $plugin = new MT::Plugin::PostToTwitter({
    name => $PLUGIN_NAME,
    version => $VERSION,
    description => "<MT_TRANS phrase='Post entry title and TinyURLed permalink to Twitter'>",
    author_name => 'M-Logic, Inc.',
    author_link => 'http://labs.m-logic.jp/',
    doc_link => 'http://labs.m-logic.jp/plugins/posttotwitter/docs/post_to_twitter.html',
    l10n_class => 'PostToTwitter::L10N',
    blog_config_template => \&template,
    settings => new MT::PluginSettings([
        ['posttotwitter_username'],
        ['posttotwitter_password'],
        ['posttotwitter_only_firstrelease', { Default => 0 } ],
        ['posttotwitter_ignore_newpost', { Default => 0 } ],
    ]),
});

MT->add_plugin($plugin);
MT->add_callback('CMSPostSave.entry', 9, $plugin, \&post_save_entry);
MT->add_callback('APIPostSave.entry', 9, $plugin, \&api_post_save_entry);
    
sub instance { $plugin; }

sub doLog {
    my ($msg) = @_; 
    use MT::Log; 
    my $log = MT::Log->new; 
    if ( defined( $msg ) ) { 
        $log->message( $msg ); 
    }
    $log->save or die $log->errstr;
    return;
}

sub template {
    my $tmpl = <<'TMPL';
<div class="setting">
<div class="label">
<label for="posttotwitter_username"><MT_TRANS phrase="Username:"></label>
</div>
<div class="field">
<p><input type="text" name="posttotwitter_username" id="posttotwitter_username" value="<TMPL_VAR NAME=POSTTOTWITTER_USERNAME ESCAPE=HTML>" /></p>
</div>

<div class="label">
<label for="posttotwitter_password"><MT_TRANS phrase="Password:"></label>
</div>
<div class="field">
<p><input type="password" name="posttotwitter_password" id="posttotwitter_password" value="<TMPL_VAR NAME=POSTTOTWITTER_PASSWORD ESCAPE=HTML>" /></p>
</div>

<div class="label">
<label for="posttotwitter_only_firstrelease"><MT_TRANS phrase="Post when:"></label>
</div>
<div class="field">
<ul>
<li><input type="checkbox" name="posttotwitter_only_firstrelease" id="posttotwitter_only_firstrelease" value="1" <TMPL_IF NAME=POSTTOTWITTER_ONLY_FIRSTRELEASE> checked="checked"</TMPL_IF> /><MT_TRANS phrase="Entry status changed from Unpublished to Published."></li>
</ul>
</div>
</div>

<div class="setting last">
<div class="label">
<label for="posttotwitter_ignore_newpost"><MT_TRANS phrase="Experimental Options:"></label>
</div>
<div class="field">
<ul>
<li><input type="checkbox" name="posttotwitter_ignore_newpost" id="posttotwitter_ignore_newpost" value="1" <TMPL_IF NAME=POSTTOTWITTER_IGNORE_NEWPOST> checked="checked"</TMPL_IF> /><MT_TRANS phrase="Ignore XML-RPC newPost method."></li>
</ul>
</div>
</div>
TMPL
}

sub posttotwitter_username {
    my $plugin = shift;
    my ($blog_id) = @_;
    my %param;
    $plugin->load_config(\%param, 'blog:'.$blog_id);
    $param{posttotwitter_username};
}

sub posttotwitter_password {
    my $plugin = shift;
    my ($blog_id) = @_;
    my %param;
    $plugin->load_config(\%param, 'blog:'.$blog_id);
    $param{posttotwitter_password};
}

sub posttotwitter_only_firstrelease {
    my $plugin = shift;
    my ($blog_id) = @_;
    my %param;
    $plugin->load_config(\%param, 'blog:'.$blog_id);
    $param{posttotwitter_only_firstrelease};
}

sub posttotwitter_ignore_newpost {
    my $plugin = shift;
    my ($blog_id) = @_;
    my %param;
    $plugin->load_config(\%param, 'blog:'.$blog_id);
    $param{posttotwitter_ignore_newpost};
}

use constant MAX_MESSAGE_LENGTH => 140;
use constant CONT_STR_LENGTH => 3;
use constant CONT_STR => '...';

sub api_post_save_entry {
    my ($eh, $app, $obj, $original) = @_;
    my $blog_id = $obj->blog_id;
    my $ignore_newpost = $plugin->posttotwitter_ignore_newpost($blog_id);
    return if $ignore_newpost && $original && $original->id != $obj->id;
    return post_save_entry($eh, $app, $obj, $original);
}

sub post_save_entry {
    my ($eh, $app, $obj, $original) = @_;
    return unless ref $obj eq 'MT::Entry';
    my $blog_id = $obj->blog_id;
    require MT::Entry;
    return unless $obj->status == MT::Entry::RELEASE();
    my $only_firstrelease = $plugin->posttotwitter_only_firstrelease($blog_id);
    return if $only_firstrelease && $original
        && $original->status == MT::Entry::RELEASE();
    my $user = $plugin->posttotwitter_username($blog_id);
    return unless defined $user;
    my $pass = $plugin->posttotwitter_password($blog_id);
    return doLog("PostToTwitter: No Password.") unless defined $pass;
    require MT::I18N;
    my $title = MT::I18N::encode_text($obj->title, undef, 'utf-8');
    my $title_length = MT::I18N::length_text($title);
    my $url = get_tinyurl($obj->permalink);
    doLog('PostToTwitter: parmalink='.$obj->permalink) if $DEBUG;
    $url = ' (' . $url . ')' if $url;
    my $url_length = $url ? MT::I18N::length_text($url) : 0;
    if($title_length + $url_length > MAX_MESSAGE_LENGTH) {
        $title_length = (MAX_MESSAGE_LENGTH - $url_length - CONT_STR_LENGTH);
        $title = MT::I18N::substr_text($title, 0, $title_length) . CONT_STR;
    }
    my $msg = ($title . $url) or return doLog("PostToTwitter: No msg.");
    require MT::Util;
    MT::Util::start_background_task(
        sub {
            return doLog("PostToTwitter: do update.") if $DEBUG;
            unless(update_twitter($user, $pass, $msg)) {
                return doLog("PostToTwitter: Failed to update.");
            }
        }
    );
}

sub get_tinyurl {
    my ($url) = @_;
    return unless $url;
    return $url if $DEBUG;
    my $api_url = 'http://tinyurl.com/api-create.php?url=';
    require LWP::Simple;
    my $tinyurl = LWP::Simple::get($api_url.$url) || '';
    return $tinyurl;
}

sub update_twitter {
    my ($user, $pass, $msg) = @_;
    my $update_url = 'http://twitter.com/statuses/update.xml';
    require LWP;
    my $ua = LWP::UserAgent->new or return;
    $ua->credentials('twitter.com:80',
                     'Twitter API',
                     $user => $pass,
                 );
    my $res = $ua->post($update_url, { status => $msg });
    return unless $res->is_success;
    return 1;
}

1;
