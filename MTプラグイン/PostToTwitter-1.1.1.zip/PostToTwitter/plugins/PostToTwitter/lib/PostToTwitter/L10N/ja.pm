package PostToTwitter::L10N::ja;

use strict;
use base 'PostToTwitter::L10N::en_us';
use vars qw( %Lexicon );

%Lexicon = (
    'Post entry title and TinyURLed permalink to Twitter' => 'エントリーのタイトルとパーマリンクのTinyURLをTwitterに投稿します。',
    'Username:' => 'ユーザ名:',
    'Password:' => 'パスワード:',
    'Post when:' => 'エントリーの投稿:',
    'Entry status changed from Unpublished to Published.' => 'エントリーの状態を未公開(下書き)から公開に変更した場合に投稿します。',
    'Experimental Options:' => '実験的なオプション:',
    'Ignore XML-RPC newPost method.' => 'XML-RPC newPostメソッドを無視します。',
    'PostToTwitter: No Username.' => 'PostToTwitter: ユーザ名が指定されていません。',
    'PostToTwitter: No Password.' => 'PostToTwitter: パスワードが指定されていません。',
    'PostToTwitter: Failed to update.' => 'PostToTwitter: 更新に失敗しました。',
);

1;
