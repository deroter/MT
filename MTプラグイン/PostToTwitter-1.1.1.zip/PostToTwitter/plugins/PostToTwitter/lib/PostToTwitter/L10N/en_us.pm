package PostToTwitter::L10N::en_us;

use strict;
use base 'PostToTwitter::L10N';
use vars qw( %Lexicon );

%Lexicon = (
);

1;
