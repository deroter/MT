package MT::Plugin::Shop_Maker;

use strict;
use MT::Plugin;
@MT::Plugin::Shop_Maker::ISA = qw(MT::Plugin);

use vars qw($PLUGIN_NAME $VERSION);
$PLUGIN_NAME = 'Shop_Maker';
$VERSION = '1.3';

use MT;
my $plugin = new MT::Plugin::Shop_Maker({
    name => $PLUGIN_NAME,
    version => $VERSION,
    description => 'Shop_Maker・セット',
    author_name => '川西アキラ',
    author_link => 'http://www.webrifo.com/',
});

MT->add_plugin($plugin);

sub init_registry {


        stylecatcher_libraries => {
            'MT-ShopMaker' => {
                url => 'http://www.movestyle.net/styles/',
                label => 'MT-ShopMaker',
                description_label => "MT-ShopMaker template style library list.",
                order => 201,
            },
        },

    my $plugin = shift;
    $plugin->registry({


        template_sets => {
            my_set => {
       	label => "Shop_Maker",
       	base_path => 'templates/',
       	base_css => 'themes-base/blog.css',
		order => 1,



	templates => {

		index => {
			'main_index' => {
                	label => 'メインページ',
                	outfile => 'index.html',
                	rebuild_me =>'1',
			},
			'archive_index' => {
			label => 'アーカイブインデックス',
			outfile => 'archives.html',
			rebuild_me =>'1',
			},
			'styles' => {
			label => 'スタイルシート(メイン)',
			outfile => 'styles.css',
			rebuild_me =>'1',
			},
			'javascript' => {
			label => 'JavaScript',
			outfile => 'mt.js',
			rebuild_me =>'1',
			},
			'feed_recent' => {
			label => '最新記事フィールド',
			outfile => 'atom.xml',
			rebuild_me =>'1',
			},
			'rsd' => {
			label => 'RSD',
			outfile => 'rsd.xml',
			rebuild_me =>'1',
			},
			'i-sitemap' => {
			label => 'サイトマップ',
			outfile => 'sitemap.html',
			rebuild_me =>'1',
			},
			'i-robots' => {
			label => 'ロボットテキスト',
			outfile => 'robots.txt',
			rebuild_me =>'1',
			},
			'i-law' => {
			label => '特定商取引に基づく表示',
			outfile => 'law/index.html',
			rebuild_me =>'1',
			},
			'i-g-sitemap-xml' => {
			label => 'グーグル用サイトマップ',
			outfile => 'sitemap.xml',
			rebuild_me =>'1',
			},

		},


	individual => {
		'entry' => {
       		label => 'ブログ記事',
             	 	mappings => {
			entry_archive => {
			archive_type => 'Individual',
			file_template => '%y%m/%-f',
			},
			},
		},
	},

	page => {
		'page' => {
			label => 'ウェブページ',
			mappings => {
			page_archive => {
			archive_type => 'Page',
			},
			},
		},
	},


	archive => {
		'category_entry_listing' => {
			label => 'カテゴリ別ブログ記事リスト',
			mappings => {
			category => {
			archive_type => 'Category',
			},
			},
		},
	},


	system => {
		'comment_response' => {
			label => 'コメント完了',
			description_label => 'Displays error, pending or confirmation message for comments.'
		},
		'comment_preview' => {
			label => 'コメントプレビュー',
			description_label => 'Displays preview of comment.',
		},
		'dynamic_error' => {
			label => 'ダイナミックパブリッシングエラー',
			description_label => 'Displays errors for dynamically published templates.',
		},
		'popup_image' => {
			label => 'ポップアップ画像',
			description_label => 'Displays image when user clicks a popup-linked image.',
		},
		'search_results' => {
			label => '検索結果',
			description_label => 'Displays results of a search.',
		},
	},



	module => {
		'comments' => {
			label => 'コメント',
		},
		'sidebar' => {
			label => 'サイドバー',
		},
		'trackbacks' => {
			label => 'トラックバック',
		},
		'banner_footer' => {
			label => 'バナーフッター',
		},
		'banner_header' => {
			label => 'バナーヘッダー',
		},
		'pan_list' => {
			label => 'パンくずリスト',
		},
		'pan_list_search_results' => {
			label => 'パンくずリスト検索結果',
		},
		'entry_summary' => {
			label => 'ブログ記事の概要',
		},
		'html_head' => {
			label => 'HTMLヘッダー',
		},
		'commonness' => {
			label => '共通（ブログ記事の概要タグクラウド・検索結果）',
		},
	},


	widget => {
		'w-menu_bana_mtshopmaker' => {
			label => 'サイドバー＞バナー　MTショップメーカー',
		},
		'w-menu_bana_osusume1' => {
			label => 'サイドバー＞バナー　オススメ商品１',
		},
		'w-menu_bana_osusume2' => {
			label => 'サイドバー＞バナー　オススメ商品２',
		},
		'w-menu_bana_otoku1' => {
			label => 'サイドバー＞バナー　お得商品１',
		},
		'w-menu_bana_ninki1' => {
			label => 'サイドバー＞バナー　人気アイテム１',
		},
		'w-menu' => {
			label => 'サイドバー＞メニュー',
		},
		'w-rss' => {
			label => 'サイドバー＞RSSを購読',
		},
		'w-update' => {
			label => 'サイドバー＞最新更新日',
		},
		'w-main-iamage' => {
			label => 'ボディー＞メイン画像',
		},
		'w-google_adsense01' => {
			label => 'ボディー＞GoogleAdSense300x250（キスト広告・左／画像広告・右）',
		},
		'w-google_adsense02' => {
			label => 'ボディー＞GoogleAdSense728x15',
		},
		'w-new' => {
			label => 'ボディー＞Whats NEW!',
		},
		'w-pop_rank' => {
			label => 'ボディー＞売れ筋ランキング一覧３列',
		},
		'w-new_goods' => {
			label => 'ボディー＞新着！毎日更新 魅力の商品続々入荷中！（５列）',
		},
		'w-more_goods' => {
			label => 'ボディー＞更に、こんな商品も購入されています。',
		},
		'w-pop_tag' => {
			label => 'ボディー＞人気タグ',
		},
		'w-your_mail' => {
			label => '共通＞あなたのメールアドレス',
		},
		'w-keywords' => {
			label => '共通＞メタキーワード',
		},
		'w-law' => {
			label => '共通＞特定商取引に基づく表示',
		},
		'w-google_analytics' => {
			label => '共通＞Googleアナリティクス',
		},
		'w-yoko_menu' => {
			label => '共通＞横メニュー',
		},

	},



	widgetset => {
		'2column_layout_sidebar' => {
			order => 1000,
			label   => '2カラム(サイドバー)',
			widgets => [
				'サイドバー＞メニュー',
				'サイドバー＞RSSを購読',
				'サイドバー＞最新更新日',
				'サイドバー＞バナー　MTショップメーカー',
				'サイドバー＞バナー　オススメ商品１',
				'サイドバー＞バナー　オススメ商品２',
				'サイドバー＞バナー　お得商品１',
				'サイドバー＞バナー　人気アイテム１',			],
		},
		'body_cat_up' => {
			order => 1000,
			label   => 'ボディー：カテゴリページ上',
			widgets => [
				'ボディー＞人気タグ',
				'ボディー＞GoogleAdSense728x15',			],
		},
		'body_cat_down' => {
			order => 1000,
			label   => 'ボディー：カテゴリページ下',
			widgets => [
				'ボディー＞更に、こんな商品も購入されています。',
				'ボディー＞GoogleAdSense300x250（キスト広告・左／画像広告・右）',
			],
		},
		'body_top' => {
			order => 1000,
			label   => 'ボディー：トップページ',
			widgets => [
				 'ボディー＞メイン画像',
				 'ボディー＞人気タグ',
				'ボディー＞GoogleAdSense728x15',
				'ボディー＞売れ筋ランキング一覧３列',
				'ボディー＞新着！毎日更新 魅力の商品続々入荷中！（５列）',
				'ボディー＞GoogleAdSense300x250（キスト広告・左／画像広告・右）',
			],
		},
		'body_blog_up' => {
			order => 1000,
			label   => 'ボディー：ブログ記事ページ上',
			widgets => [
				'ボディー＞人気タグ',
				'ボディー＞GoogleAdSense728x15',	
			],
		},
		'body_blog_down' => {
			order => 1000,
			label   => 'ボディー：ブログ記事ページ下',
			widgets => [
				'ボディー＞更に、こんな商品も購入されています。',
				'ボディー＞GoogleAdSense300x250（キスト広告・左／画像広告・右）',
			],
		},
		'body_search_results_up' => {
			order => 1000,
			label   => 'ボディー：人気タグ・検索結果上',
			widgets => [
				'ボディー＞人気タグ',
				'ボディー＞GoogleAdSense728x15',	
			],
		},
		'body_search_results_down' => {
			order => 1000,
			label   => 'ボディー：人気タグ・検索結果下',
			widgets => [
				'ボディー＞GoogleAdSense300x250（キスト広告・左／画像広告・右）',
			],
		},
		'commonness_your_mail' => {
			order => 1000,
			label   => '共通：あなたのメールアドレス',
			widgets => [
				'共通＞あなたのメールアドレス',
			],
		},
		'commonness_meta_keyword' => {
			order => 1000,
			label   => '共通：メタキーワード',
			widgets => [
				'共通＞メタキーワード',
			],
		},
		'commonness_law' => {
			order => 1000,
			label   => '共通：特定商取引に基づく表示',
			widgets => [
				'共通＞特定商取引に基づく表示',
			],
		},
		'commonness_analytics' => {
			order => 1000,
			label   => '共通：Googleアナリティクス',
			widgets => [
				'共通＞Googleアナリティクス',
			],
		},
		'commonness_menu' => {
			order => 1000,
			label   => '共通：横メニュー',
			widgets => [
				'共通＞横メニュー',
			],
		},


	system => {
			 'comment_preview' => {
			     label => 'Comment Preview',
	                },
			 'comment_response' => {
			     label => 'Comment Response',
	                },
			 'dynamic_error' => {
			     label => 'Dynamic Error',
	                },
			 'popup_image' => {
			     label => 'Popup Image',
	                },
			 'search_results' => {
			     label => 'Search Results',
	                },
		},



	},




				},
			},
		},
	});
}

1;
