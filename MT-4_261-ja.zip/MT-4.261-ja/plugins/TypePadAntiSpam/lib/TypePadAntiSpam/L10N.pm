# Movable Type (r) (C) 2005-2009 Six Apart, Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id: L10N.pm 81360 2008-05-21 03:39:58Z fyoshimatsu $

package TypePadAntiSpam::L10N;
use strict;
use base 'MT::Plugin::L10N';

1;
