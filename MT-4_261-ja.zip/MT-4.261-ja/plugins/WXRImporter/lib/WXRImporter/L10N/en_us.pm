# WXRImporter plugin for Movable Type
# Author: Byrne Reese, Six Apart (http://www.sixapart.com)
# Released under the Artistic License
#
# $Id: en_us.pm 1098 2007-12-12 01:47:58Z hachi $

package WXRImporter::L10N::en_us;

use strict;

use base 'WXRImporter::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
