# Movable Type (r) (C) 2006-2009 Six Apart, Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id: L10N.pm 3455 2009-02-23 02:29:31Z auno $

# Original Copyright (c) 2004-2006 David Raynes

package MultiBlog::L10N;

use strict;
use base 'MT::Plugin::L10N';

1;
