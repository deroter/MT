# Movable Type (r) (C) 2006-2009 Six Apart, Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id: L10N.pm 3455 2009-02-23 02:29:31Z auno $

# Original copyright (c) 2004-2006, Brad Choate and Tobias Hoellrich

package spamlookup::L10N;
use strict;

use MT::Plugin::L10N;
@spamlookup::L10N::ISA = qw(MT::Plugin::L10N);

1;
